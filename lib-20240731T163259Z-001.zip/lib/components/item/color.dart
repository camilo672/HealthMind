import 'package:flutter/material.dart';

const primaryColor = Color.fromARGB(255, 255, 111, 67);
const canvasColor = Color.fromARGB(255, 28, 125, 189);
const scaffoldBackgroundColor = Color.fromARGB(255, 242, 248, 253);
const accentCanvasColor = Color.fromARGB(255, 62, 78, 97);
const white = Colors.white;
final actionColor = Color.fromARGB(255, 95, 167, 157).withOpacity(0.6);
final divider = Divider(color: white.withOpacity(0.3), height: 1);