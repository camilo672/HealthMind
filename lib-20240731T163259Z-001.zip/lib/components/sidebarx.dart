library sidebarx;

export 'src/src.dart';
