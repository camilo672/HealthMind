import 'package:flutter/material.dart';

/// Default builder method for sidebar elements building
typedef SidebarXBuilder = Widget Function(BuildContext context, bool extended);
