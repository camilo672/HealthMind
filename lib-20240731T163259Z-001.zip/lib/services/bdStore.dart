
import 'package:cloud_firestore/cloud_firestore.dart';
FirebaseFirestore db = FirebaseFirestore.instance;



  Future<void> setUser(String name, String email , String password) async{
    await db.collection('Usuarios').add({
    'FulName':name,
    'email':email,
    'password':password});

  }
  Future<void> addAppointment( String reason, String description, String  title, DateTime time,String name
  ) async{

     await db.collection('appointment').add({
    'title': title,
    'content':description,
    'reason':reason,
    'time':time,
    'name':name
 });

  }





 



