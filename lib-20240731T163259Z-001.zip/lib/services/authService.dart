import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;

class AuthService {
  // Cerrar sesión
  Future<void> signOut() async {
    await _auth.signOut();
  }
}

  // Verificar si el usuario existe
Future<Map<String, dynamic>> checkIfUserExists(String id, String codigoInstitucional, String password) async {
  try {
    print('Iniciando verificación de usuario con ID: $id, Código Institucional: $codigoInstitucional y Password: $password');

    final FirebaseFirestore _firestore = FirebaseFirestore.instance;
    QuerySnapshot querySnapshot = await _firestore
      .collection('Usuarios-E') // Reemplaza 'usuarios' con el nombre de tu colección
      .where('id', isEqualTo: id)
      .where('codigoInstitucional', isEqualTo: codigoInstitucional)
      .where('password', isEqualTo: password)
      .get();

    print('Consulta realizada con ${querySnapshot.docs.length} resultados');

    if (querySnapshot.docs.isNotEmpty) {
      DocumentSnapshot idUsuario = querySnapshot.docs.first;
      print('Usuario encontrado: ${idUsuario.id}');
      return {
        "exists": true,
        "documentID": idUsuario.id,
        "name": idUsuario.get("name"),
        "age": idUsuario.get("age"),
        "gender": idUsuario.get("gender"),
        "role": idUsuario.get("role")
      }; // El documento existe
    } else {
      print('Usuario no encontrado');
      return {
        "exists": false,
        "documentID": null
      }; // El documento no existe
    }
  } catch (e) {
    print('Error encontrado: $e');
    // Retorna un mapa indicando que ocurrió un error
    return {
      "exists": false,
      "documentID": null,
      "error": e.toString()
    };
  }
}

