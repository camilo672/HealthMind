import 'package:flutter/material.dart';
import 'screens/mainScreen/mainpage.dart';
import 'firebase_options.dart';

import 'screens/login/welcome.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform
  );
  runApp(const PhsyCho());
}

class PhsyCho extends StatelessWidget {
  const PhsyCho({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bienvenido',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        ),
        initialRoute: WelcomeScreen.routename,
        routes: {
          WelcomeScreen.routename : (context)=> const  WelcomeScreen(),
          Mainpage.routename :(context)=>  Mainpage(),
        },
      );
    }
  }
