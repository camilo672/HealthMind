import 'package:flutter/material.dart';
import 'message.dart';

class ChatsScreen extends StatefulWidget {
  @override
  _ChatsScreenState createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  final List<String> _grades = ['6', '7', '8', '9', '10', '11'];
  final Map<String, List<String>> _courses = {
    '6': ['1', '2', '3', '4'],
    '7': ['1', '2', '3', '4'],
    '8': ['1', '2', '3', '4'],
    '9': ['1', '2', '3'],
    '10': ['1', '2', '3'],
    '11': ['1', '2', '3'],
  };

  final Map<String, Map<String, List<String>>> _students = {
    '6': {'1': ['Estudiante 1', 'Estudiante 2'], '2': ['Estudiante 3', 'Estudiante 4'], '3': ['Estudiante 5', 'Estudiante 6'], '4': ['Estudiante 7', 'Estudiante 8']},
    '7': {'1': ['Estudiante 9', 'Estudiante 10'], '2': ['Estudiante 11', 'Estudiante 12'], '3': ['Estudiante 13', 'Estudiante 14'], '4': ['Estudiante 15', 'Estudiante 16']},
    '8': {'1': ['Estudiante 17', 'Estudiante 18'], '2': ['Estudiante 19', 'Estudiante 20'], '3': ['Estudiante 21', 'Estudiante 22'], '4': ['Estudiante 23', 'Estudiante 24']},
    '9': {'1': ['Estudiante 25', 'Estudiante 26'], '2': ['Estudiante 27', 'Estudiante 28'], '3': ['Estudiante 29', 'Estudiante 30']},
    '10': {'1': ['Estudiante 31', 'Estudiante 32'], '2': ['Estudiante 33', 'Estudiante 34'], '3': ['Estudiante 35', 'Estudiante 36']},
    '11': {'1': ['Estudiante 37', 'Estudiante 38'], '2': ['Estudiante 39', 'Estudiante 40'], '3': ['Estudiante 41', 'Estudiante 42']},
  };

  Map<String, List<String>> _studentConversations = {}; // Conversaciones de estudiantes

  String? _selectedGrade;
  String? _selectedCourse;
  List<String> _selectedStudents = [];
  String _selectedStudent = '';

  final TextEditingController _controller = TextEditingController();

  void _sendMessage() {
    final String message = _controller.text.trim();
    if (message.isNotEmpty) {
      setState(() {
        if (_studentConversations[_selectedStudent] == null) {
          _studentConversations[_selectedStudent] = [];
        }
        _studentConversations[_selectedStudent]!.add(message);
      });
      _controller.clear();
    }
  }

  void _updateCourse(String? course) {
    setState(() {
      _selectedCourse = course;
      if (_selectedGrade != null && _selectedCourse != null) {
        _selectedStudents = _students[_selectedGrade]![_selectedCourse!]!;
        if (_selectedStudents.isNotEmpty) {
          _selectedStudent = _selectedStudents.first;
          // Initialize conversation if not already done
          if (_studentConversations[_selectedStudent] == null) {
            _studentConversations[_selectedStudent] = [];
          }
        }
      }
    });
  }

  void _updateGrade(String? grade) {
    setState(() {
      _selectedGrade = grade;
      _selectedCourse = null;
      _selectedStudents = [];
      if (grade != null) {
        _updateCourse(_courses[grade]?.first);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Barra lateral fija para seleccionar grado y curso
          Container(
            width: 250.0,
            color: Colors.blue[100],
            child: Column(
              children: [
                DropdownButton<String>(
                  value: _selectedGrade,
                  hint: Text('Selecciona el grado'),
                  items: _grades.map((grade) {
                    return DropdownMenuItem<String>(
                      value: grade,
                      child: Text(grade),
                    );
                  }).toList(),
                  onChanged: _updateGrade,
                ),
                if (_selectedGrade != null)
                  DropdownButton<String>(
                    value: _selectedCourse,
                    hint: Text('Selecciona el curso'),
                    items: _courses[_selectedGrade]!.map((course) {
                      return DropdownMenuItem<String>(
                        value: course,
                        child: Text(course),
                      );
                    }).toList(),
                    onChanged: _updateCourse,
                  ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _selectedStudents.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(_selectedStudents[index]),
                        onTap: () {
                          setState(() {
                            _selectedStudent = _selectedStudents[index];
                            // Initialize conversation if not already done
                            if (_studentConversations[_selectedStudent] == null) {
                              _studentConversations[_selectedStudent] = [];
                            }
                          });
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          // Sección principal para el chat
          Expanded(
            child: Column(
              children: [
                AppBar(
                  title: Text(_selectedStudent),
                  backgroundColor: Colors.blue,
                ),
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(8.0),
                    itemCount: _studentConversations[_selectedStudent]?.length ?? 0,
                    itemBuilder: (context, index) {
                      final isSent = index % 2 == 0; // Alternar entre mensajes enviados y recibidos
                      return MessageWidget(
                        isSent: isSent,
                        message: _studentConversations[_selectedStudent]![index],
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            hintText: 'Escribe un mensaje...',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                          ),
                        ),
                      ),
                      SizedBox(width: 8.0),
                      IconButton(
                        icon: Icon(Icons.send),
                        onPressed: _sendMessage,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


