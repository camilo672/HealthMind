import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:intl/intl.dart';
import 'package:phsycho/screens/login/singin.dart';
import 'package:phsycho/services/bdStore.dart';
import 'notice_card.dart';

class NoticesScreen extends StatefulWidget {
  @override
  _NoticesPageState createState() => _NoticesPageState();
}

class _NoticesPageState extends State<NoticesScreen> {
  Map<String,dynamic> infoUser = SignInScreenState.infoUser;

  final GlobalKey<FormBuilderState> _formKey = GlobalKey<FormBuilderState>();
  List<NoticeCard> _settingCards = [];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          if(infoUser['role']==0)
          Column(
                  children: [
          Text(
            'Anuncio',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          FormBuilder(
            key: _formKey,
            child: Column(
              children: [
             

                
                FormBuilderTextField(
                  name: 'title',
                  decoration:const InputDecoration(
                    labelText: 'Título',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                FormBuilderTextField(
                  name: 'reason',
                  decoration: InputDecoration(
                    labelText: 'Motivo',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                FormBuilderTextField(
                  name: 'content',
                  decoration: InputDecoration(
                    labelText: 'Contenido',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState?.saveAndValidate() ?? false) {
                      var formData = _formKey.currentState?.value;
                      String title = formData!['title'];
                      String reason = formData['reason'];
                      String content = formData['content'];
                      DateTime now = DateTime.now();

                      await addAppointment(reason, content, title, now, infoUser["name"]);
                      setState(() {
                        _settingCards.add(NoticeCard(
                          title: title,
                          reason: reason,
                          content: content,
                          formattedDate: DateFormat('hh:mm a').format(now),
                          name: infoUser["name"],
                        ));
                      });
                      _formKey.currentState?.reset();
                    }
                  },
                  child: Text('Publicar anuncio'),
                ),
              ],
            ),
    )]),
      SizedBox(height: 32),
  Text(
            'Anuncios publicados',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          StreamBuilder(
            stream: FirebaseFirestore.instance.collection('appointment').orderBy('time', descending: true).snapshots(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return Center(child: Text('No hay Anuncios disponibles'));
              }

              return ListView(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: snapshot.data!.docs.map((doc) {
                  var data = doc.data() as Map<String, dynamic>;
                  Timestamp timestamp = data['time'];
                  DateTime dateTime = timestamp.toDate();
                  String formattedDate = DateFormat('dd-MM-yy-   hh:mm a').format(dateTime);
                  return NoticeCard(
                    title: data['title'] ?? 'Sin título',
                    reason: data['reason'] ?? 'Sin motivo',
                    content: data['content'] ?? 'Sin contenido',
                    formattedDate: formattedDate,
                    name: data['name']??'No registra',
                    
             
                  );
                }).toList(),
              );
            },
          )]));
        
    
    
  }

  @override
  void initState() {
    super.initState();
  }
}


