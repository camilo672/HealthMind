import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
//agenda de citas 
class AppointmentsPage extends StatefulWidget {
  @override
  _AppointmentsPageState createState() => _AppointmentsPageState();
}

class _AppointmentsPageState extends State<AppointmentsPage> {
  final GlobalKey<FormBuilderState> _formKey = GlobalKey<FormBuilderState>();
  List<Map<String, dynamic>> _appointments = [];

  String _filter = 'pending'; // Filtro inicial

  void _showConfirmationDialog(BuildContext context, Map<String, dynamic> appointment) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Cita Agendada'),
          content: Text(
              'La cita con ${appointment['student']} para ${appointment['reason']} ha sido agendada para el ${DateFormat.yMMMd().format(appointment['datetime'])} a las ${DateFormat.jm().format(appointment['datetime'])}.'),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showEditOptionsDialog(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Editar Cita'),
          content: Text('¿Qué acción deseas realizar con esta cita?'),
          actions: [
            TextButton(
              child: Text('Cancelar'),
              onPressed: () {
                setState(() {
                  _appointments[index]['status'] = 'cancelled';
                });
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Resolver'),
              onPressed: () {
                setState(() {
                  _appointments[index]['status'] = 'resolved';
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'resolved':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      case 'pending':
      default:
        return Colors.yellow;
    }
  }

  void _applyFilter(String filter) {
    setState(() {
      _filter = filter;
    });
  }

  List<Map<String, dynamic>> _getFilteredAppointments() {
    if (_filter == 'pending') {
      return _appointments.where((appointment) => appointment['status'] == 'pending').toList();
    } else if (_filter == 'resolved') {
      return _appointments.where((appointment) => appointment['status'] == 'resolved').toList();
    } else if (_filter == 'cancelled') {
      return _appointments.where((appointment) => appointment['status'] == 'cancelled').toList();
    } else {
      return _appointments;
    }
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredAppointments = _getFilteredAppointments();

    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Agendar Cita',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          FormBuilder(
            key: _formKey,
            child: Column(
              children: [
                FormBuilderDropdown(
                  name: 'student',
                  decoration: InputDecoration(
                    labelText: 'Estudiante',
                    border: OutlineInputBorder(),
                  ),
                  items: const[
                    DropdownMenuItem(
                      value: 'Juan Perez',
                      child: Text('Juan Perez'),
                    ),
                    DropdownMenuItem(
                      value: 'Ana Gomez',
                      child: Text('Ana Gomez'),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                FormBuilderTextField(
                  name: 'reason',
                  decoration: InputDecoration(
                    labelText: 'Motivo',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                FormBuilderTextField(
                  name: 'description',
                  decoration: InputDecoration(
                    labelText: 'Descripción',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                FormBuilderDateTimePicker(
                  name: 'datetime',
                  inputType: InputType.both,
                  decoration: InputDecoration(
                    labelText: 'Fecha y Hora',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState?.saveAndValidate() ?? false) {
                      var formData = _formKey.currentState?.value;
                      var newAppointment = {
                        'student': formData!['student'],
                        'reason': formData['reason'],
                        'description': formData['description'],
                        'datetime': formData['datetime'],
                        'status': 'pending',
                      };
                      setState(() {
                        _appointments.add(newAppointment);
                      });
                      _showConfirmationDialog(context, newAppointment);
                    }
                  },
                  child: Text('Iniciar Chat'),
                ),
              ],
            ),
          ),
          SizedBox(height: 32),
          Text(
            'Citas Agendadas',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          TableCalendar(
            firstDay: DateTime.utc(2020, 10, 16),
            lastDay: DateTime.utc(2030, 3, 14),
            focusedDay: DateTime.now(),
            calendarBuilders: CalendarBuilders(
              markerBuilder: (context, date, events) {
                final appointmentsForDay = _appointments
                    .where((appointment) => isSameDay(appointment['datetime'], date))
                    .toList();

                if (appointmentsForDay.isNotEmpty) {
                  return Positioned(
                    right: 2,
                    bottom: 2,
                    child: _buildEventsMarker(appointmentsForDay),
                  );
                }
                return null;
              },
            ),
            eventLoader: (day) {
              return _appointments
                  .where((appointment) => isSameDay(appointment['datetime'], day))
                  .toList();
            },
            onDaySelected: (selectedDay, focusedDay) {
              _showAppointmentsDialog(context, selectedDay);
            },
          ),
          SizedBox(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Filtrar Citas'),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ListTile(
                              title: Text('Pendientes'),
                              onTap: () {
                                _applyFilter('pending');
                                Navigator.of(context).pop();
                              },
                            ),
                            ListTile(
                              title: Text('Resueltas'),
                              onTap: () {
                                _applyFilter('resolved');
                                Navigator.of(context).pop();
                              },
                            ),
                            ListTile(
                              title: Text('Canceladas'),
                              onTap: () {
                                _applyFilter('cancelled');
                                Navigator.of(context).pop();
                              },
                            ),
                            ListTile(
                              title: Text('Mostrar Todas'),
                              onTap: () {
                                _applyFilter('all');
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
                child: Text('Filtrar Citas'),
              ),
            ],
          ),
          SizedBox(height: 16),
          Text(
            'Citas Pendientes',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: filteredAppointments.length,
            itemBuilder: (context, index) {
              final appointment = filteredAppointments[index];
              return Card(
                child: ListTile(
                  title: Text('${appointment['student']} - ${appointment['reason']}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${DateFormat.yMMMd().format(appointment['datetime'])} a las ${DateFormat.jm().format(appointment['datetime'])}',
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Estado: ${appointment['status']}',
                        style: TextStyle(
                          color: _getStatusColor(appointment['status']),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      _showEditOptionsDialog(context, index);
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildEventsMarker(List<Map<String, dynamic>> appointmentsForDay) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _getStatusColor(appointmentsForDay.first['status']),
      ),
      width: 16.0,
      height: 16.0,
      child: Center(
        child: Text(
          '${appointmentsForDay.length}',
          style: TextStyle().copyWith(
            color: Colors.white,
            fontSize: 12.0,
          ),
        ),
      ),
    );
  }

  void _showAppointmentsDialog(BuildContext context, DateTime date) {
    final appointmentsForDay = _appointments
        .where((appointment) => isSameDay(appointment['datetime'], date))
        .toList();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(DateFormat.yMMMMd().format(date)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: appointmentsForDay
              .map((appointment) => ListTile(
                    title: Text(appointment['student']),
                    subtitle: Text('${appointment['reason']}\n${appointment['description']}\n${appointment['status']}'),
                    trailing: Text(DateFormat.jm().format(appointment['datetime'])),
                  ))
              .toList(),
        ),
      ),
    );
  }
  
}